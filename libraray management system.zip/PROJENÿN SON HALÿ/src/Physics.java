
public class Physics extends Module1 {
    public void physics(){
        System.out.println("");
        String phy[]={"Mechanics","Dynamics","Solid State Physics","Astro Physics","Electromagnetism"};

        System.out.println("The books available in Physics department are as follow:");

        for(int j=0; j<phy.length;j++){

            System.out.println(phy[j]);
        }
    }
    public void Module1Func(){
        System.out.println("Physics in MODULE 1");
    }
}
