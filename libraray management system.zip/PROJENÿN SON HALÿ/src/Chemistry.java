

import java.util.ArrayList;

interface MyModuleInterface{
    public void myinterface();
}
class Chemistry extends Module1{
    public void chemistry(){
        System.out.println("");
        String chem[]={"Organic chemistry","Physical chemistry","Bio chemistry","Inorganic chemistry","Polymer chemistry"};

        System.out.println("The books available in chemistry department are as follow:");
        for (int i=0; i< chem.length;i++){

            System.out.println(chem[i]);
        }
    }
}
