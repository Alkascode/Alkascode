import java.util.ArrayList;
public class Biology extends Module1 {
    public void biology(){

        System.out.println("");
        String bio[]={"Zoology","Botany","Medical Science","xyz","abc"};
        ArrayList<String> myStringList = new ArrayList<String>();
        myStringList.add("Zoology");
        myStringList.add("Botany");
        myStringList.add("Medical Science");
        myStringList.add("xyz");
        myStringList.add("abc");
        myStringList.forEach((n)->{System.out.println("my lambda exercise : " + n);});

    }

    public static void main(String[] args) {
        Module1 myobjmodul1bio = new Module1();
        myobjmodul1bio.Module1Func();
    }
    public void Module1Func(){
        System.out.println("Biology in MODULE 1");
    }
}
