
public class Module2 extends Chemistry {

    public static void main(String[] args) {
        Module2 myobjche = new Module2();
        myobjche.chemistry();
    }
}
